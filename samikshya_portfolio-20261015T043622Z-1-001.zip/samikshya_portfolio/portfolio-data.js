/**
 * SAMIKSHYA GHIMIRE — PORTFOLIO DATA STORE
 * Centralized data repository for projects, engineering capabilities, profile, and stats.
 * Enables zero-code visual editing via the Admin Panel (admin.html) with localStorage persistence.
 */

const DEFAULT_PORTFOLIO_DATA = {
  profile: {
    name: "Samikshya Ghimire",
    initials: "SG",
    title: "Mechanical Design Engineer & Product Designer",
    eyebrow: "MECHANICAL DESIGN ENGINEER · CAD & DFMA",
    heroHeadline: "Engineering complex ideas into",
    heroHeadlineGradient: "high-precision reality.",
    heroDescription: "Specializing in multi-part CAD assemblies, precision packaging, injection-molding tooling studies, and kinematic reverse engineering grounded in real-world manufacturing constraints.",
    statusText: "AVAILABLE FOR ROLES",
    email: "contact@samikshyaghimire.com",
    linkedin: "https://www.linkedin.com/in/samikshya-ghimire/",
    pdfUrl: "Design Portfolio Samikshya Ghimire.pdf",
    tags: [
      "Autodesk Fusion 360",
      "DFMA & Mold Design",
      "GD&T Tolerances (ASME Y14.5)",
      "Kinematic Motion Studies",
      "Reverse Engineering"
    ],
    aboutHeadline: "Design decisions grounded in how things are actually fabricated.",
    aboutParagraphs: [
      "I am a Mechanical Engineer and Product Designer focused on turning theoretical ideas into reliable, physical mechanisms. My design philosophy bridges the gap between aesthetic product design and manufacturing discipline—ensuring that every line drawn in CAD can be molded, machined, welded, or 3D printed cost-effectively.",
      "My portfolio spans high-precision horological packaging (ETA 2895-2 automatic movement), mechatronic camera gimbals, vintage mechanism reverse-engineering, agricultural machinery, and rigorous plastic injection molding studies."
    ]
  },

  stats: [
    { number: "08", accent: "+", label: "Engineered Systems", desc: "Multi-part kinematic assemblies" },
    { number: "±0.015", accent: "mm", label: "Precision Tolerances", desc: "Horology & CNC machine fits" },
    { number: "100", accent: "%", label: "DFMA Grounded", desc: "Draft angles & wall thickness logic" },
    { number: "2nd", accent: "Pl", label: "Ergo-Reignite Award", desc: "SOIES Nepal & FSU ergonomics" }
  ],

  capabilities: [
    {
      num: "01 / CAD",
      title: "Parametric CAD & Complex Assemblies",
      desc: "Multi-body kinematics, assembly joints, motion constraints, and interference analysis in Autodesk Fusion 360.",
      tags: ["Fusion 360", "Kinematics", "GD&T"]
    },
    {
      num: "02 / DFMA",
      title: "DFMA & Tooling Feasibility",
      desc: "Constant wall thickness analysis, core/cavity draft verification, parting line logic, and tooling cost minimization.",
      tags: ["Injection Molding", "Draft Analysis", "Parting Lines"]
    },
    {
      num: "03 / REVERSE",
      title: "Kinematic Reverse Engineering",
      desc: "Reconstructing legacy linkages and physical mechanisms from patent drawings, video teardowns, and constraint analysis.",
      tags: ["Linkage Analysis", "Cam Timing", "Geometric Inference"]
    },
    {
      num: "04 / R&D",
      title: "Rapid Prototyping & Mechatronics",
      desc: "FDM print orientation for shear strength, electronics packaging, motor torque fitment, and iterative physical testing.",
      tags: ["FDM 3D Printing", "Motor Mounts", "Sensors & Wire Routing"]
    }
  ],

  toolchains: [
    {
      category: "CAD & Modeling Suite",
      items: ["Autodesk Fusion 360", "Parametric Modeling", "T-Splines & Freeform", "Motion Study & Kinematics"]
    },
    {
      category: "Manufacturing & Tooling",
      items: ["DFMA Principles", "Injection Mold Tooling", "5-Axis CNC Machining", "FDM 3D Printing / Slicing", "Sheet Metal & Welding"]
    },
    {
      category: "Engineering Standards",
      items: ["GD&T (ASME Y14.5)", "Tolerance Stack-Up", "Ergonomics & Human Factors"]
    }
  ],

  projects: [
    {
      id: "watchcase",
      featured: true,
      discipline: "precision",
      categoryName: "Precision Horology & CNC",
      badge: "ETA 2895-2 Calibre Packaging",
      software: "Fusion 360 · GD&T",
      title: "High-Precision Horology: Custom Automatic Watch Case",
      shortDesc: "A high-precision mechanical packaging study engineered around the strict microscopic tolerances of a live ETA 2895-2 Swiss automatic movement.",
      heroImg: "assets/renders/watchcase_blue.png",
      gallery: [
        { img: "assets/renders/watchcase_blue.png", caption: "Precision Stainless Steel Case with Custom Crown-Guard" },
        { img: "assets/renders/watchcase_red.png", caption: "Crimson Red Dial Variant & Bezel Indexing" }
      ],
      originalSlide: "assets/page-9.png",
      cadPreset: "watchcase",
      challenge: "Designing a luxury tool watch case that balances high-end ergonomics and wearable proportions with the rigid, microscopic internal tolerances required to house a live ETA 2895-2 automatic movement.",
      cadArchitecture: "Engineered a multi-component parametric assembly in Autodesk Fusion 360 incorporating strict dimensional constraints for stem height, dial thickness, hand clearances, and dual front/rear sapphire crystals. Developed a custom, original-geometry crown-guard lever mechanism.",
      dfmaStrategy: "Designed explicitly for multi-axis CNC machining out of marine-grade 316L and 904L stainless steel. Case diameter, wall thickness, and lug-to-lug geometry were optimized to balance structural robustness with wearable ergonomic balance.",
      takeaways: "Demonstrated that small-scale product design demands absolute precision where aesthetics fluidly merge with mechanical constraints. Future phases include GD&T tolerance stack-up analysis for prototype manufacturing validation.",
      specs: {
        material: "Marine 316L / 904L Stainless",
        process: "5-Axis Precision CNC Milling & Turning",
        movement: "ETA 2895-2 Automatic (28,800 vph)",
        sealing: "Sapphire Crystal O-Ring & Lever Lock",
        tolerance: "±0.015 mm Critical Fits"
      }
    },
    {
      id: "gimbal",
      featured: false,
      discipline: "mechatronics",
      categoryName: "Mechatronics & R&D",
      badge: "Cross-Department R&D",
      software: "Fusion 360 · FDM",
      title: "3-Axis Mechatronic Camera Gimbal",
      shortDesc: "A cost-conscious, high-rigidity camera gimbal structure engineered to house brushless motors, camera payload, and electronics control boards.",
      heroImg: "assets/renders/gimbal_cad.png",
      gallery: [
        { img: "assets/renders/gimbal_cad.png", caption: "CAD Model Optimized for FDM 3D Printing" },
        { img: "assets/renders/gimbal_proto.png", caption: "Physical Prototype Assembly & Wiring Test" }
      ],
      originalSlide: "assets/page-2.png",
      cadPreset: "gimbal",
      challenge: "Commercial gimbal components exceeded project budget constraints. Required a custom, cost-effective mechanical structure to house motors, support the camera payload, and integrate seamlessly with the electronics team's control system.",
      cadArchitecture: "Developed original CAD models optimized specifically for FDM 3D printing in Fusion 360. Focused heavily on rapid prototyping constraints, reducing material usage while ensuring stiffness and part interchangeability.",
      dfmaStrategy: "Collaborated closely with the electronics department to align motor mounts and camera positioning. Iterated the design to improve mechanical-electronic fitment and vibration dampening during high-speed stabilization.",
      takeaways: "Reinforced the reality of working under strict resource limitations, proving that mechanical design must fluidly adapt to electronic constraints and real-world fabrication capabilities.",
      specs: {
        material: "Carbon-Fiber PETG / Tough PLA",
        process: "Additive Manufacturing (FDM 3D Print)",
        payload: "Micro-Camera & Sensor Pod",
        fasteners: "M2.5 / M3 Stainless Hardware",
        tolerance: "±0.15 mm Prototyping Fit"
      }
    },
    {
      id: "sewing",
      featured: false,
      discipline: "reverse",
      categoryName: "Reverse Engineering",
      badge: "Kinematic Reconstruction",
      software: "Fusion 360 Assemblies",
      title: "Singer Model 20 Sewing Machine",
      shortDesc: "A complete, functional 3D CAD reverse engineering reconstruction of the vintage \"Sewhandy\" chain-stitch mechanism from historical drawings.",
      heroImg: "assets/renders/singer_cad.png",
      gallery: [
        { img: "assets/renders/singer_cad.png", caption: "Full CAD Reconstruction of Singer Model 20 Assembly" }
      ],
      originalSlide: "assets/page-4.png",
      cadPreset: "linkage",
      challenge: "Reconstructing an intricate vintage chain-stitch motion-conversion mechanism in the complete absence of physical parts or modern digital schematics.",
      cadArchitecture: "Built an intricate multi-part assembly in Fusion 360 by interpreting historical 2D patent drawings and teardown video footage. Successfully synchronized rotary handwheel input to reciprocating needle motion.",
      dfmaStrategy: "Mapped internal linkages to understand rotary-to-reciprocating motion and synchronized timing loops. Developed constraint-based parametric sketches for historic cast-iron body geometries.",
      takeaways: "Cultivated a rigorous geometric inference mindset and an appreciation for historical design logic—analyzing how complex mechanisms were engineered without digital tools.",
      specs: {
        mechanism: "Rotary-to-Reciprocating Chain Stitch",
        source: "Historical 2D Patents & Teardowns",
        parts: "18 Parametric Components",
        motion: "Eccentric Cam & Synchronized Looper",
        software: "Autodesk Fusion 360"
      }
    },
    {
      id: "spraypen",
      featured: false,
      discipline: "consumer",
      categoryName: "Consumer Products",
      badge: "Compact Fluid Packaging",
      software: "Fusion 360 · CAD",
      title: "Concealed Defensive EDC: Premium Spray Pen",
      shortDesc: "A conceptual mechanical packaging exercise integrating a compact fluid-delivery system inside a minimalist executive writing instrument.",
      heroImg: "assets/renders/spraypen_cad.png",
      gallery: [
        { img: "assets/renders/spraypen_cad.png", caption: "Executive Writing Instrument Form Factor" },
        { img: "assets/renders/spraypen_exploded.png", caption: "Internal Actuation Spring & Nozzle Packaging" },
        { img: "assets/renders/spraypen_tip.png", caption: "Precision Machined Brass/Gold Tip Detail" }
      ],
      originalSlide: "assets/page-5.png",
      cadPreset: "cylinder",
      challenge: "Traditional personal safety devices look overly tactical or intimidating, discouraging daily carry. The objective was to design a discreet, non-threatening personal safety tool packaged inside a luxury pen.",
      cadArchitecture: "Re-engineered the internal fluid delivery system in Fusion 360, modeling the exact packaging for the actuation spring, release valve, fluid cartridge, and directional nozzle to ensure functional alignment.",
      dfmaStrategy: "Sleek outer chassis featuring a minimalist black-and-gold aesthetic inspired by luxury accessories, successfully balancing ergonomics, user psychology, and discreet deployment.",
      takeaways: "Highlighted the tight intersection of mechanical packaging and user perception. Future iterations will focus on fluid flow simulation and modular interchangeable cartridges.",
      specs: {
        material: "6061 Anodized Aluminum & Brass",
        actuation: "Concealed Plunger & Spring Valve",
        capacity: "Refillable Micro-Aerosol Cartridge",
        diameter: "14.0 mm Outer Barrel",
        software: "Autodesk Fusion 360"
      }
    },
    {
      id: "oilpress",
      featured: false,
      discipline: "machine",
      categoryName: "Machine Design & DFMA",
      badge: "Agricultural Technology",
      software: "Fusion 360 · Weldments",
      title: "Decentralized Small-Scale Oil Expeller",
      shortDesc: "An affordable, locally manufacturable dual-input (manual/motorized) screw-press machine for decentralized agricultural processing.",
      heroImg: "assets/renders/oilpress_full.png",
      gallery: [
        { img: "assets/renders/oilpress_full.png", caption: "Complete Small-Scale Oil Expeller Machine Assembly" },
        { img: "assets/renders/oilpress_iso.png", caption: "Perforated Extraction Barrel & Feed Hopper" },
        { img: "assets/renders/oilpress_side.png", caption: "Structural Frame & Transmission Integration" }
      ],
      originalSlide: "assets/page-8.png",
      cadPreset: "screw",
      challenge: "Traditional household oil extraction is labor-intensive, while commercial alternatives face severe cost and supply chain barriers. The goal was an affordable, dual-input expeller empowering local farmers.",
      cadArchitecture: "Engineered a complete screw-press system in Fusion 360. Modeled all critical sub-assemblies, optimizing interactions between feed hopper, perforated barrel, Archimedes helical screw shaft, frame, and collection tray.",
      dfmaStrategy: "Spearheaded material selection using food-grade 304 stainless steel for all oil-contact zones and cost-effective mild steel for the structural chassis. Designed explicitly for low-tech workshop sheet metal forming and welding.",
      takeaways: "Transitioned from part-level modeling to complex multi-component systems engineering under real-world resource constraints. Future phases include Archimedes screw torque optimization.",
      specs: {
        contactZones: "Food-Grade 304 Stainless Steel",
        chassis: "Formed & Welded Mild Steel Channel",
        drive: "Dual Input: Manual Crank / Motorized Pulley",
        mechanism: "Variable-Pitch Progressive Screw",
        software: "Autodesk Fusion 360"
      }
    },
    {
      id: "icetray",
      featured: false,
      discipline: "dfma",
      categoryName: "DFMA & Mold Design",
      badge: "Flex-to-Release Tooling",
      software: "Fusion 360 Mold Tools",
      title: "Single-Cavity Injection-Molded Ice Tray",
      shortDesc: "A single-cavity DFM study focusing on flex-to-release elastic behavior, draft angles, and uniform cooling for high-volume consumer goods.",
      heroImg: "assets/renders/icetray_iso.png",
      gallery: [
        { img: "assets/renders/icetray_iso.png", caption: "Isometric View of 14-Pocket Grid" },
        { img: "assets/renders/icetray_top.png", caption: "Underside Ribs & Ejection Strategy" },
        { img: "assets/renders/icetray_blue.png", caption: "Material TPE/LDPE Flex Color Study" }
      ],
      originalSlide: "assets/page-6.png",
      cadPreset: "tray",
      challenge: "A flex-to-release tray only works if the part deforms elastically thousands of times without fatigue cracking, while stripping cleanly from a single-cavity steel tool without manual rework.",
      cadArchitecture: "Held wall thickness to a constant 1.5–1.8 mm across all 14 cells. Applied 1.5° draft on cavity walls (2.0° on deeper cells) so the tray strips cleanly off the core without scuffing.",
      dfmaStrategy: "Designed as a straight-pull, two-plate mold: no side-actions or undercuts. Center-gated at the underside rib to keep melt flow path balanced across all 14 cavities and ensure symmetric fill.",
      takeaways: "A tray looks trivial, but fails production fastest if draft, wall thickness, or gate placement are wrong. Getting fundamentals airtight here is what makes discipline reliable on complex housings.",
      specs: {
        material: "Food-Grade LDPE / Elastic TPE",
        wallThickness: "1.5 mm – 1.8 mm (Constant)",
        draftAngle: "1.5° – 2.0° Cavity Walls",
        tooling: "2-Plate Straight-Pull, Center-Gated",
        cavities: "Single-Cavity, 14 Cells"
      }
    },
    {
      id: "flowerbowl",
      featured: false,
      discipline: "dfma",
      categoryName: "DFMA & Mold Design",
      badge: "Aesthetic Freeform DFM",
      software: "Fusion 360 T-Splines",
      title: "Organic Flower-Form Decorative Bowl",
      shortDesc: "A double-curved sculptural bowl proving that organic aesthetic geometry can rigorously satisfy injection molding discipline.",
      heroImg: "assets/renders/flowerbowl_persp.png",
      gallery: [
        { img: "assets/renders/flowerbowl_persp.png", caption: "Freeform Double-Curved Petal Geometry" },
        { img: "assets/renders/flowerbowl_top.png", caption: "Top Down View Showing Rim Parting Line" },
        { img: "assets/renders/flowerbowl_bottom.png", caption: "Underside Curvature & Constant Shell Offset" }
      ],
      originalSlide: "assets/page-7.png",
      cadPreset: "shell",
      challenge: "Organic double-curved petal surfaces are where DFM discipline usually breaks down—the constraints that keep a boxy enclosure moldable get harder to hold when every face has varying local curvature.",
      cadArchitecture: "Built the shell from offset surfaces to hold a constant ~2.0 mm wall through every petal. Draft was inspected petal-by-petal (1°–3° varying with local slope) to avoid undercuts.",
      dfmaStrategy: "Parting line follows the natural rim silhouette, keeping this an economical two-piece mold despite the organic form—confirming no petal creates a trapped undercut on core or cavity.",
      takeaways: "Proves wall-thickness and draft discipline isn't just a boxy enclosure trick—it holds up on freeform, aesthetic-first surfaces, separating viable CAD from non-manufacturable concepts.",
      specs: {
        material: "High-Gloss PP or ABS Polymer",
        wallThickness: "2.0 mm Uniform Offset Shell",
        draftAngle: "1.0° – 3.0° Normal-Varying Draft",
        partingLine: "Natural Undulating Rim Silhouette",
        tooling: "2-Piece Simple Mold (Zero Side-Actions)"
      }
    },
    {
      id: "whiteboard",
      featured: false,
      discipline: "consumer",
      categoryName: "Consumer Products",
      badge: "2nd Place Ergo-Reignite Award",
      software: "Fusion 360 · Wood Joinery",
      title: "Classroom Ergonomics Whiteboard Organizer",
      shortDesc: "A compact utility shelf awarded 2nd Place in the Ergo-Reignite Design Competition, engineered around anthropometric reach and low-cost manufacturing.",
      heroImg: "assets/renders/whiteboard_shelf.png",
      gallery: [
        { img: "assets/renders/whiteboard_shelf.png", caption: "Ergonomic Stepped Shelf Holding Markers & Eraser" },
        { img: "assets/renders/whiteboard_full.png", caption: "Classroom Wall-Mounted Environment Render" },
        { img: "assets/renders/whiteboard_empty.png", caption: "Clean Wooden Joinery Structure" }
      ],
      originalSlide: "assets/page-3.png",
      cadPreset: "shelf",
      challenge: "Classrooms frequently suffer from misplaced markers and teaching tools, disrupting lecture flow. Required a compact, ergonomically optimized utility shelf mounted beside whiteboards.",
      cadArchitecture: "Co-developed the product concept; modeled the stepped shelf and classroom environment in Fusion 360. Angled marker rests ensure intuitive grab-and-replace reach.",
      dfmaStrategy: "Integrated basic DFMA principles to ensure simple fabrication using leftover wood and basic workshop tools. Designed with interlocking dado joints for maximum durability.",
      takeaways: "Proved that effective engineering design isn't about forced complexity—it is about solving real-world human factors in the simplest, most cost-effective way possible.",
      specs: {
        award: "2nd Place (SOIES Nepal & FSU)",
        material: "Reclaimed Hardwood / Timber Off-Cuts",
        joinery: "Dado & Rabbet Mechanical Interlocks",
        capacity: "4 Dry-Erase Markers + Felt Eraser",
        software: "Autodesk Fusion 360"
      }
    }
  ]
};

// Global helper functions for Data Management
const PortfolioStore = {
  STORAGE_KEY: "samikshya_portfolio_db_v2",

  get() {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Merge with defaults to ensure any missing fields exist
        return {
          profile: { ...DEFAULT_PORTFOLIO_DATA.profile, ...(parsed.profile || {}) },
          stats: parsed.stats && parsed.stats.length ? parsed.stats : DEFAULT_PORTFOLIO_DATA.stats,
          capabilities: parsed.capabilities && parsed.capabilities.length ? parsed.capabilities : DEFAULT_PORTFOLIO_DATA.capabilities,
          toolchains: parsed.toolchains && parsed.toolchains.length ? parsed.toolchains : DEFAULT_PORTFOLIO_DATA.toolchains,
          projects: parsed.projects && parsed.projects.length ? parsed.projects : DEFAULT_PORTFOLIO_DATA.projects
        };
      }
    } catch (e) {
      console.warn("Error reading from localStorage, using defaults:", e);
    }
    return JSON.parse(JSON.stringify(DEFAULT_PORTFOLIO_DATA));
  },

  save(data) {
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
      // Notify other open tabs/windows
      window.dispatchEvent(new CustomEvent("portfolioDataUpdated", { detail: data }));
      return true;
    } catch (e) {
      console.error("Error saving portfolio data:", e);
      return false;
    }
  },

  reset() {
    try {
      localStorage.removeItem(this.STORAGE_KEY);
      window.dispatchEvent(new CustomEvent("portfolioDataUpdated", { detail: DEFAULT_PORTFOLIO_DATA }));
      return true;
    } catch (e) {
      console.error("Error resetting data:", e);
      return false;
    }
  },

  exportJSON() {
    const data = this.get();
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
    const dlAnchor = document.createElement("a");
    dlAnchor.setAttribute("href", dataStr);
    dlAnchor.setAttribute("download", `samikshya_portfolio_backup_${new Date().toISOString().split("T")[0]}.json`);
    dlAnchor.click();
    dlAnchor.remove();
  },

  importJSON(jsonString) {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.projects || !Array.isArray(parsed.projects)) {
        throw new Error("Invalid format: missing projects array");
      }
      this.save(parsed);
      return { success: true };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }
};

// Expose to window for global access
window.DEFAULT_PORTFOLIO_DATA = DEFAULT_PORTFOLIO_DATA;
window.PortfolioStore = PortfolioStore;
