SAMIKSHYA GHIMIRE — MECHANICAL ENGINEERING PORTFOLIO WEBSITE

Open index.html in a browser.

Before publishing, replace the contact placeholder with Samikshya's real email, LinkedIn and resume link.
All project imagery/content is based on the supplied portfolio PDF.

Suggested deployment: Netlify, GitHub Pages, Vercel or upload to your existing hosting.
