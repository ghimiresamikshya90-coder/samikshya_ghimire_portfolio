/**
 * SAMIKSHYA GHIMIRE — MECHANICAL ENGINEERING PORTFOLIO
 * High-Performance Dynamic, Data-Driven & 3D Interactive Engine
 * 
 * Features:
 * - Dynamic data binding with PortfolioStore (Zero-Code Admin Sync)
 * - Synthesized Mechanical Audio Feedback (Web Audio API)
 * - Hero 3D CAD Mechanism with 3 Modes:
 *     1. Planetary Reduction Gearset (with Exploded View)
 *     2. Swiss Horology Balance & Escapement (Ticking Escapement)
 *     3. 3-Axis Kinematic Gimbal Assembly
 * - 3D Internal Section-Cut Clipping Plane
 * - Floating 3D Engineering Dimension Callouts
 * - Interactive 3D CAD Model Viewer inside Project Modal (8 CAD Presets)
 * - 3D Perspective Card Tilt & Metallic Glare
 * - Real-time Project Search & Multi-Discipline Filter
 * - Engineering Spec Sheet Matrix View
 */

// ==========================================================================
// 1. Data Store & Global State
// ==========================================================================
let portfolioDb = PortfolioStore.get();
let currentFilter = 'all';
let searchQuery = '';
let currentProjectIndex = 0;

// Hero 3D State
let activeAssemblyMode = 'planetary'; // 'planetary' | 'horology' | 'gimbal'
let isWireframeMode = false;
let isSectionCutMode = false;
let isDimensionsVisible = false;
let explodedValue = 0;
let rotationSpeed = 1.0;

// Modal 3D State
let modalThree = null; // { scene, camera, renderer, masterGroup, isWireframe }
let soundEnabled = localStorage.getItem('sg_sound_enabled') !== 'false';

// ==========================================================================
// 2. Synthesized Mechanical Sound FX (Web Audio API)
// ==========================================================================
const AudioFX = {
  ctx: null,

  init() {
    if (!this.ctx && (window.AudioContext || window.webkitAudioContext)) {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    }
  },

  playClick() {
    if (!soundEnabled) return;
    this.init();
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1400, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, this.ctx.currentTime + 0.035);

    gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.035);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.04);
  },

  playRatchet() {
    if (!soundEnabled) return;
    this.init();
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(800, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(150, this.ctx.currentTime + 0.025);

    gain.gain.setValueAtTime(0.05, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.025);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.03);
  },

  playEscapementTick() {
    if (!soundEnabled) return;
    this.init();
    if (!this.ctx) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(2400, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(600, this.ctx.currentTime + 0.02);

    gain.gain.setValueAtTime(0.03, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.02);

    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.025);
  }
};

// Sound Toggle Button
function initSoundToggle() {
  const btn = document.querySelector('#soundToggle');
  const icon = document.querySelector('#soundIcon');
  const label = document.querySelector('#soundLabel');
  if (!btn) return;

  const updateSoundUI = () => {
    btn.classList.toggle('muted', !soundEnabled);
    if (icon) icon.textContent = soundEnabled ? '🔊' : '🔇';
    if (label) label.textContent = soundEnabled ? 'SOUND: ON' : 'SOUND: OFF';
  };
  updateSoundUI();

  btn.addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    localStorage.setItem('sg_sound_enabled', soundEnabled);
    updateSoundUI();
    if (soundEnabled) AudioFX.playClick();
  });
}

// ==========================================================================
// 3. Dynamic Profile & Content Rendering
// ==========================================================================
function renderProfileContent() {
  const p = portfolioDb.profile || {};

  // Nav brand
  const navBrandMark = document.querySelector('#navBrandMark');
  const navBrandName = document.querySelector('#navBrandName');
  if (navBrandMark) navBrandMark.textContent = p.initials || 'SG';
  if (navBrandName) navBrandName.textContent = p.name || 'Samikshya Ghimire';

  // Nav links
  const navPdf = document.querySelector('#navPdfLink');
  const heroPdf = document.querySelector('#heroPdfLink');
  const contactPdf = document.querySelector('#contactPdfLink');
  const footerPdf = document.querySelector('#footerPdfLink');
  [navPdf, heroPdf, contactPdf, footerPdf].forEach(link => {
    if (link && p.pdfUrl) link.href = p.pdfUrl;
  });

  const navStatusText = document.querySelector('#navStatusText');
  if (navStatusText) navStatusText.textContent = p.statusText || 'AVAILABLE FOR ROLES';

  // Hero Copy
  const heroEyebrowText = document.querySelector('#heroEyebrowText');
  if (heroEyebrowText) heroEyebrowText.textContent = p.eyebrow || 'MECHANICAL DESIGN ENGINEER · CAD & DFMA';

  const heroHeadlinePrefix = document.querySelector('#heroHeadlinePrefix');
  const heroHeadlineGradient = document.querySelector('#heroHeadlineGradient');
  if (heroHeadlinePrefix) heroHeadlinePrefix.textContent = p.heroHeadline || 'Engineering complex ideas into';
  if (heroHeadlineGradient) heroHeadlineGradient.textContent = p.heroHeadlineGradient || 'high-precision reality.';

  const heroDescription = document.querySelector('#heroDescription');
  if (heroDescription) heroDescription.textContent = p.heroDescription || '';

  // Hero Tags
  const heroTags = document.querySelector('#heroTags');
  if (heroTags && p.tags) {
    heroTags.innerHTML = p.tags.map(t => `<span>${t}</span>`).join('');
  }

  // Stats Ribbon
  const statsGrid = document.querySelector('#statsGrid');
  if (statsGrid && portfolioDb.stats) {
    statsGrid.innerHTML = portfolioDb.stats.map(s => `
      <div class="stat-item reveal in">
        <div class="stat-number">${s.number}<span class="accent">${s.accent}</span></div>
        <div class="stat-label">${s.label}</div>
        <div class="stat-desc">${s.desc}</div>
      </div>
    `).join('');
  }

  // Capabilities
  const capabilitiesGrid = document.querySelector('#capabilitiesGrid');
  if (capabilitiesGrid && portfolioDb.capabilities) {
    capabilitiesGrid.innerHTML = portfolioDb.capabilities.map(c => `
      <div class="cap-card reveal in">
        <span class="cap-num">${c.num}</span>
        <h3 class="cap-title">${c.title}</h3>
        <p class="cap-desc">${c.desc}</p>
        <div class="cap-tags">
          ${(c.tags || []).map(t => `<span class="cap-tag">${t}</span>`).join('')}
        </div>
      </div>
    `).join('');
  }

  // About Section
  const aboutHeadline = document.querySelector('#aboutHeadline');
  if (aboutHeadline) aboutHeadline.textContent = p.aboutHeadline || 'Design decisions grounded in how things are actually fabricated.';

  const aboutBio = document.querySelector('#aboutBio');
  if (aboutBio && p.aboutParagraphs) {
    aboutBio.innerHTML = p.aboutParagraphs.map(text => `<p>${text}</p>`).join('');
  }

  // Toolchains
  const toolchainsWrap = document.querySelector('#toolchainsWrap');
  if (toolchainsWrap && portfolioDb.toolchains) {
    toolchainsWrap.innerHTML = portfolioDb.toolchains.map(tc => `
      <div class="toolchain-card">
        <span class="toolchain-title">${tc.category}</span>
        <div class="toolchain-list">
          ${tc.items.map(i => `<span class="tool-badge">${i}</span>`).join('')}
        </div>
      </div>
    `).join('');
  }

  // Contact
  const contactEmail = document.querySelector('#contactEmailLink');
  if (contactEmail && p.email) {
    contactEmail.href = `mailto:${p.email}`;
  }

  // Footer
  const footerCopyright = document.querySelector('#footerCopyright');
  if (footerCopyright) {
    footerCopyright.textContent = `© 2026 ${p.name || 'Samikshya Ghimire'} · ${p.title || 'Mechanical Design Engineer'}`;
  }
}

// ==========================================================================
// 4. Render Project Cards & Spec Sheet Matrix
// ==========================================================================
const projectsGrid = document.querySelector('#projectsGrid');
const specMatrixWrap = document.querySelector('#specMatrixWrap');
const specTableBody = document.querySelector('#specTableBody');
const filterBtns = document.querySelectorAll('.filter-btn');
const viewBtns = document.querySelectorAll('.view-btn');
const projectSearchInput = document.querySelector('#projectSearchInput');

function getFilteredProjects() {
  let list = portfolioDb.projects || [];

  if (currentFilter !== 'all') {
    list = list.filter(p => p.discipline === currentFilter);
  }

  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase().trim();
    list = list.filter(p => {
      const matchTitle = (p.title || '').toLowerCase().includes(q);
      const matchDesc = (p.shortDesc || '').toLowerCase().includes(q);
      const matchCat = (p.categoryName || '').toLowerCase().includes(q);
      const matchBadge = (p.badge || '').toLowerCase().includes(q);
      const matchSpecs = Object.values(p.specs || {}).some(v => String(v).toLowerCase().includes(q));
      return matchTitle || matchDesc || matchCat || matchBadge || matchSpecs;
    });
  }

  return list;
}

function renderProjects() {
  const filtered = getFilteredProjects();

  // Update counter
  const filterCountAll = document.querySelector('#filterCountAll');
  if (filterCountAll) {
    filterCountAll.textContent = `(${portfolioDb.projects.length})`;
  }

  if (filtered.length === 0) {
    projectsGrid.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 60px 20px; background: rgba(12,17,26,0.6); border: 1px dashed var(--border-card); border-radius: var(--radius-lg);">
        <p style="font-size: 18px; color: #fff; margin-bottom: 8px;">No systems match your filter/search criteria.</p>
        <p style="font-size: 13px; color: var(--text-muted); font-family: var(--font-mono);">Try clearing the search box or selecting "All Systems".</p>
      </div>
    `;
    specTableBody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">No matching specifications found.</td></tr>`;
    return;
  }

  // Render Grid Cards
  projectsGrid.innerHTML = filtered.map((proj) => {
    const isFeatured = proj.featured && currentFilter === 'all' && !searchQuery.trim();
    return `
      <article class="project-card ${isFeatured ? 'featured' : ''} reveal in" data-id="${proj.id}" tabindex="0">
        <div class="card-media">
          <div class="card-cad-grid"></div>
          <div class="badge-tag">
            <span class="red-dot"></span>
            <span>${proj.badge || 'CAD System'}</span>
          </div>
          <div class="badge-software">${proj.software || 'Fusion 360'}</div>
          <div class="card-img-wrap">
            <img src="${proj.heroImg}" alt="${proj.title}" loading="lazy" onerror="this.src='assets/renders/watchcase_blue.png'">
          </div>
        </div>
        <div class="card-content">
          <div class="card-top">
            <span class="card-category">${proj.categoryName || proj.discipline}</span>
            <h3 class="card-title">${proj.title}</h3>
            <p class="card-desc">${proj.shortDesc}</p>
          </div>
          <div class="card-specs">
            ${Object.entries(proj.specs || {}).slice(0, 3).map(([k, v]) => `
              <span class="spec-pill"><strong>${k.toUpperCase()}:</strong> ${v}</span>
            `).join('')}
          </div>
          <div class="card-footer">
            <button class="btn-inspect">
              <span>Inspect Engineering System</span>
              <span class="arrow">↗</span>
            </button>
            <span class="card-blueprint-hint">3D CAD + Blueprint</span>
          </div>
        </div>
      </article>
    `;
  }).join('');

  // Render Table Matrix
  specTableBody.innerHTML = filtered.map(proj => `
    <tr data-id="${proj.id}">
      <td>
        <span class="table-proj-name">${proj.title}</span>
        <div style="font-size: 11px; color: var(--red-bright); font-family: var(--font-mono); margin-top: 2px;">
          ${proj.categoryName || proj.discipline}
        </div>
      </td>
      <td><span class="table-badge">${(proj.specs && proj.specs.material) || 'Engineered Alloy'}</span></td>
      <td>${(proj.specs && (proj.specs.process || proj.specs.mechanism)) || 'Multi-Component Assembly'}</td>
      <td><code>${(proj.specs && (proj.specs.tolerance || proj.specs.wallThickness)) || '±0.015 mm'}</code></td>
      <td>${proj.software || 'Fusion 360'}</td>
      <td>
        <button class="btn-inspect" style="font-size: 12px; padding: 4px 10px;">Inspect ↗</button>
      </td>
    </tr>
  `).join('');

  // Attach card click handlers
  document.querySelectorAll('.project-card, .spec-table tr').forEach(el => {
    el.addEventListener('click', (e) => {
      const id = el.dataset.id;
      if (!id) return;
      const index = (portfolioDb.projects || []).findIndex(p => p.id === id);
      if (index !== -1) {
        AudioFX.playClick();
        openProjectModal(index);
      }
    });
  });

  // Attach 3D Card Perspective Tilt
  attachCard3DTilt();
}

// 3D Card Perspective Tilt with Metallic Reflection Glint
function attachCard3DTilt() {
  document.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('pointermove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = ((y - centerY) / centerY) * -6; // max -6 to +6 deg
      const rotateY = ((x - centerX) / centerX) * 6;  // max -6 to +6 deg

      card.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-4px)`;
      card.style.setProperty('--mouse-x', `${(x / rect.width * 100).toFixed(1)}%`);
      card.style.setProperty('--mouse-y', `${(y / rect.height * 100).toFixed(1)}%`);
    });

    card.addEventListener('pointerleave', () => {
      card.style.transform = '';
    });
  });
}

// Filter button clicks
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    AudioFX.playRatchet();
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    renderProjects();
  });
});

// View switch (Grid vs Spec Matrix)
viewBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    AudioFX.playClick();
    viewBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const view = btn.dataset.view;
    if (view === 'grid') {
      projectsGrid.style.display = 'grid';
      specMatrixWrap.classList.remove('active');
    } else {
      projectsGrid.style.display = 'none';
      specMatrixWrap.classList.add('active');
    }
  });
});

// Real-time Instant Search
if (projectSearchInput) {
  projectSearchInput.addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderProjects();
  });
}

// Ambient Cursor Glow
const cursorGlow = document.querySelector('.cursor-glow');
window.addEventListener('pointermove', (e) => {
  if (cursorGlow) {
    cursorGlow.style.left = `${e.clientX}px`;
    cursorGlow.style.top = `${e.clientY}px`;
  }
});

// ==========================================================================
// 5. Immersive Case Study Modal & 3D CAD Inspector
// ==========================================================================
const modalOverlay = document.querySelector('#projectModalOverlay');
const modalCloseBtn = document.querySelector('#modalCloseBtn');
const modalDiscipline = document.querySelector('#modalDiscipline');
const modalTitle = document.querySelector('#modalTitle');
const modalMainImg = document.querySelector('#modalMainImg');
const modalThumbs = document.querySelector('#modalThumbs');
const modalBlueprintPane = document.querySelector('#modalBlueprintPane');
const modalBlueprintImg = document.querySelector('#modalBlueprintImg');
const modalGalleryPane = document.querySelector('#modalGalleryPane');
const modalCad3dPane = document.querySelector('#modalCad3dPane');
const modalChallenge = document.querySelector('#modalChallenge');
const modalCad = document.querySelector('#modalCad');
const modalDfma = document.querySelector('#modalDfma');
const modalTakeaways = document.querySelector('#modalTakeaways');
const modalSpecGrid = document.querySelector('#modalSpecGrid');
const modalTabBtns = document.querySelectorAll('.modal-tab-btn');
const modalPrevBtn = document.querySelector('#modalPrevBtn');
const modalNextBtn = document.querySelector('#modalNextBtn');

function openProjectModal(index) {
  currentProjectIndex = index;
  const proj = portfolioDb.projects[index];
  if (!proj) return;

  populateModal(proj);
  modalOverlay.classList.add('open');
  document.body.style.overflow = 'hidden';

  // Default to gallery tab on open
  switchModalTab('gallery');
}

function closeProjectModal() {
  AudioFX.playClick();
  modalOverlay.classList.remove('open');
  document.body.style.overflow = '';
}

function switchModalTab(tab) {
  modalTabBtns.forEach(b => b.classList.toggle('active', b.dataset.tab === tab));

  modalGalleryPane.style.display = tab === 'gallery' ? 'flex' : 'none';
  modalBlueprintPane.classList.toggle('active', tab === 'blueprint');
  modalCad3dPane.classList.toggle('active', tab === 'cad3d');

  if (tab === 'cad3d') {
    const proj = portfolioDb.projects[currentProjectIndex];
    initModal3DViewer(proj ? proj.cadPreset || 'watchcase' : 'watchcase');
  }
}

function populateModal(proj) {
  modalDiscipline.textContent = `${proj.categoryName || proj.discipline} · ${proj.badge || 'CAD System'}`;
  modalTitle.textContent = proj.title;
  modalMainImg.src = proj.heroImg;

  // Blueprints
  modalBlueprintImg.src = proj.originalSlide || 'assets/page-1.png';

  // Thumbnails
  const gallery = proj.gallery && proj.gallery.length ? proj.gallery : [{ img: proj.heroImg, caption: proj.title }];
  modalThumbs.innerHTML = gallery.map((item, idx) => `
    <div class="modal-thumb ${idx === 0 ? 'active' : ''}" data-src="${item.img}">
      <img src="${item.img}" alt="${item.caption || proj.title}">
    </div>
  `).join('');

  modalThumbs.querySelectorAll('.modal-thumb').forEach(thumb => {
    thumb.addEventListener('click', () => {
      AudioFX.playClick();
      modalThumbs.querySelectorAll('.modal-thumb').forEach(t => t.classList.remove('active'));
      thumb.classList.add('active');
      modalMainImg.src = thumb.dataset.src;
    });
  });

  // Deep dive copy
  modalChallenge.textContent = proj.challenge || 'No challenge description provided.';
  modalCad.textContent = proj.cadArchitecture || 'Parametric assembly and kinematic joints modeled in Autodesk Fusion 360.';
  modalDfma.textContent = proj.dfmaStrategy || 'Manufacturability, draft angles, wall thickness, and tooling constraints validated.';
  modalTakeaways.textContent = proj.takeaways || 'Successfully validated the kinematic and manufacturing parameters.';

  // Specs Matrix Grid
  modalSpecGrid.innerHTML = Object.entries(proj.specs || {}).map(([k, v]) => `
    <div class="modal-spec-card">
      <span>${k}</span>
      <strong>${v}</strong>
    </div>
  `).join('');
}

// Modal Tabs
modalTabBtns.forEach(tabBtn => {
  tabBtn.addEventListener('click', () => {
    AudioFX.playClick();
    switchModalTab(tabBtn.dataset.tab);
  });
});

// Modal Nav
modalPrevBtn.addEventListener('click', () => {
  AudioFX.playClick();
  const total = portfolioDb.projects.length;
  currentProjectIndex = (currentProjectIndex - 1 + total) % total;
  populateModal(portfolioDb.projects[currentProjectIndex]);
  const activeTab = document.querySelector('.modal-tab-btn.active');
  if (activeTab && activeTab.dataset.tab === 'cad3d') {
    initModal3DViewer(portfolioDb.projects[currentProjectIndex].cadPreset || 'watchcase');
  }
});

modalNextBtn.addEventListener('click', () => {
  AudioFX.playClick();
  const total = portfolioDb.projects.length;
  currentProjectIndex = (currentProjectIndex + 1) % total;
  populateModal(portfolioDb.projects[currentProjectIndex]);
  const activeTab = document.querySelector('.modal-tab-btn.active');
  if (activeTab && activeTab.dataset.tab === 'cad3d') {
    initModal3DViewer(portfolioDb.projects[currentProjectIndex].cadPreset || 'watchcase');
  }
});

modalCloseBtn.addEventListener('click', closeProjectModal);
modalOverlay.addEventListener('click', (e) => {
  if (e.target === modalOverlay) closeProjectModal();
});

window.addEventListener('keydown', (e) => {
  if (!modalOverlay.classList.contains('open')) return;
  if (e.key === 'Escape') closeProjectModal();
  if (e.key === 'ArrowLeft') modalPrevBtn.click();
  if (e.key === 'ArrowRight') modalNextBtn.click();
});

// ==========================================================================
// 6. Interactive 3D CAD Inspector inside Modal (Three.js)
// ==========================================================================
function initModal3DViewer(preset = 'watchcase') {
  const canvas = document.querySelector('#modalCadCanvas');
  if (!canvas || !window.THREE) return;

  const presetLabel = document.querySelector('#modalCadPresetLabel');
  if (presetLabel) {
    presetLabel.textContent = `● INTERACTIVE 3D CAD: ${preset.toUpperCase()} GEOMETRY`;
  }

  // Dispose previous instance if active
  if (modalThree && modalThree.renderer) {
    modalThree.renderer.dispose();
  }

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(40, canvas.clientWidth / canvas.clientHeight, 0.1, 100);
  camera.position.set(0, 1.2, 5.5);

  const renderer = new THREE.WebGLRenderer({
    canvas,
    alpha: true,
    antialias: true
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(canvas.clientWidth, canvas.clientHeight, false);
  renderer.outputEncoding = THREE.sRGBEncoding;

  // Assembly Group
  const masterGroup = new THREE.Group();
  scene.add(masterGroup);

  // Lighting
  scene.add(new THREE.HemisphereLight(0xffffff, 0x050912, 1.5));
  const dirLight = new THREE.DirectionalLight(0xffffff, 2.0);
  dirLight.position.set(4, 5, 5);
  scene.add(dirLight);

  const redPoint = new THREE.PointLight(0xff2d55, 10, 10);
  redPoint.position.set(-3, -2, 3);
  scene.add(redPoint);

  // Materials
  const titaniumMat = new THREE.MeshStandardMaterial({ color: 0xd8e2ec, metalness: 0.9, roughness: 0.15 });
  const redMat = new THREE.MeshStandardMaterial({ color: 0xff1e46, metalness: 0.85, roughness: 0.2, emissive: 0x3d000f, emissiveIntensity: 0.2 });
  const goldMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.8, roughness: 0.25 });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x182030, metalness: 0.7, roughness: 0.35 });
  const wireMat = new THREE.MeshBasicMaterial({ color: 0xff476d, wireframe: true });

  const meshRegistry = [];
  function addM(mesh, mat = titaniumMat) {
    mesh.material = mat;
    meshRegistry.push({ mesh, solid: mat });
    masterGroup.add(mesh);
    return mesh;
  }

  // Build Procedural 3D Preset
  if (preset === 'watchcase') {
    // Watch Case: outer bezel, chamfered lugs, crown with teeth, crystal
    addM(new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 0.45, 64), titaniumMat));
    addM(new THREE.Mesh(new THREE.TorusGeometry(1.62, 0.08, 16, 64), redMat));
    // Crown
    const crown = addM(new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.3, 24), goldMat));
    crown.rotation.z = Math.PI / 2;
    crown.position.set(1.75, 0, 0);
    // 4 Lugs
    [[-1.3, 1.7], [1.3, 1.7], [-1.3, -1.7], [1.3, -1.7]].forEach(([lx, ly]) => {
      const lug = addM(new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.7, 0.35), titaniumMat));
      lug.position.set(lx, ly * 0.9, 0);
      lug.rotation.z = lx > 0 ? -0.2 : 0.2;
    });
    // Crystal
    const crystal = addM(new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 0.05, 48), new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      metalness: 0.1,
      roughness: 0.05,
      transparent: true,
      opacity: 0.6
    })));
    crystal.position.z = 0.25;
    crystal.rotation.x = Math.PI / 2;
  } else if (preset === 'gimbal') {
    // 3-Axis Gimbal Frame
    addM(new THREE.Mesh(new THREE.TorusGeometry(1.8, 0.08, 16, 64), redMat));
    const innerRing = addM(new THREE.Mesh(new THREE.TorusGeometry(1.3, 0.07, 16, 64), titaniumMat));
    innerRing.rotation.y = 0.6;
    // Camera cradle
    const cradle = addM(new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.8, 0.6), darkMat));
    cradle.position.set(0, 0, 0);
    // Motor collars
    const m1 = addM(new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.3, 24), goldMat));
    m1.position.set(0, 1.8, 0);
    const m2 = addM(new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.3, 24), goldMat));
    m2.position.set(1.3, 0, 0);
    m2.rotation.z = Math.PI / 2;
  } else if (preset === 'linkage') {
    // Kinematic Cam & Reciprocating Needle Linkage
    addM(new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.9, 0.25, 48), darkMat));
    // Eccentric pin
    const pin = addM(new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.6, 16), redMat));
    pin.position.set(0.45, 0, 0.2);
    pin.rotation.x = Math.PI / 2;
    // Connecting Rod
    const rod = addM(new THREE.Mesh(new THREE.BoxGeometry(0.16, 1.6, 0.1), titaniumMat));
    rod.position.set(0.45, 0.8, 0.2);
    // Needle Bar
    const needle = addM(new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.2, 16), titaniumMat));
    needle.position.set(0, 1.2, 0.2);
  } else if (preset === 'screw') {
    // Archimedes Helical Screw
    addM(new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 3.2, 32), titaniumMat));
    for (let i = 0; i < 7; i++) {
      const flight = addM(new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.12, 12, 32), goldMat));
      flight.position.y = -1.2 + i * 0.4;
      flight.rotation.x = Math.PI / 2 + 0.35;
    }
    // Perforated barrel half
    const halfBarrel = addM(new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, 3.0, 32, 1, true, 0, Math.PI), darkMat));
    halfBarrel.rotation.y = Math.PI / 2;
  } else {
    // Precision Cylinder / Default
    addM(new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 3.0, 32), titaniumMat));
    const cap = addM(new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.6, 32), redMat));
    cap.position.y = 1.3;
    const nozzle = addM(new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.5, 24), goldMat));
    nozzle.position.y = -1.7;
    nozzle.rotation.x = Math.PI;
  }

  let dragging = false;
  let lastX = 0, lastY = 0;
  let rotX = 0.2, rotY = -0.4;
  let isWire = false;

  canvas.onpointerdown = (e) => {
    dragging = true;
    lastX = e.clientX;
    lastY = e.clientY;
    canvas.setPointerCapture(e.pointerId);
  };
  canvas.onpointermove = (e) => {
    if (dragging) {
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      rotY += dx * 0.01;
      rotX += dy * 0.01;
      lastX = e.clientX;
      lastY = e.clientY;
    }
  };
  canvas.onpointerup = () => { dragging = false; };
  canvas.onpointerleave = () => { dragging = false; };

  // Wireframe toggle button inside modal
  const wireBtn = document.querySelector('#modalCadWireframeBtn');
  if (wireBtn) {
    wireBtn.onclick = () => {
      AudioFX.playClick();
      isWire = !isWire;
      wireBtn.classList.toggle('active', isWire);
      meshRegistry.forEach(({ mesh, solid }) => {
        mesh.material = isWire ? wireMat : solid;
      });
    };
  }

  // Reset button inside modal
  const resetBtn = document.querySelector('#modalCadResetBtn');
  if (resetBtn) {
    resetBtn.onclick = () => {
      AudioFX.playClick();
      rotX = 0.2;
      rotY = -0.4;
    };
  }

  // Animation Loop
  let reqId;
  function animate() {
    reqId = requestAnimationFrame(animate);
    if (!dragging) {
      rotY += 0.005; // gentle idle rotation
    }
    masterGroup.rotation.x = rotX;
    masterGroup.rotation.y = rotY;
    renderer.render(scene, camera);
  }
  animate();

  modalThree = { renderer, scene, camera, masterGroup, reqId };
}

// ==========================================================================
// 7. Hero 3D Mechanical Viewport (Three Assembly Modes + Section Cut)
// ==========================================================================
function initHeroThreeMechanism() {
  const canvas = document.querySelector('#mechanismCanvas');
  if (!canvas || !window.THREE) return;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(38, canvas.clientWidth / canvas.clientHeight, 0.1, 100);
  camera.position.set(0, 1.2, 7.5);

  const renderer = new THREE.WebGLRenderer({
    canvas,
    alpha: true,
    antialias: true
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.localClippingEnabled = true;

  // Master Root
  const masterAssembly = new THREE.Group();
  scene.add(masterAssembly);

  // Section Cut Clipping Plane (cuts along Z-X axis through center)
  const clipPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

  // Materials Library
  const materials = {
    redMetal: new THREE.MeshStandardMaterial({
      color: 0xff1e46,
      metalness: 0.88,
      roughness: 0.18,
      emissive: 0x3d000f,
      emissiveIntensity: 0.2
    }),
    titanium: new THREE.MeshStandardMaterial({
      color: 0xe0e7ee,
      metalness: 0.94,
      roughness: 0.14
    }),
    goldBrass: new THREE.MeshStandardMaterial({
      color: 0xffb703,
      metalness: 0.85,
      roughness: 0.22
    }),
    stealthDark: new THREE.MeshStandardMaterial({
      color: 0x111622,
      metalness: 0.7,
      roughness: 0.35
    }),
    wireframeRed: new THREE.MeshBasicMaterial({
      color: 0xff2d55,
      wireframe: true
    }),
    wireframeWhite: new THREE.MeshBasicMaterial({
      color: 0xffffff,
      wireframe: true
    })
  };

  const registeredMeshes = [];
  function reg(mesh, solidMat = materials.titanium) {
    mesh.material = solidMat;
    registeredMeshes.push({ mesh, solidMat });
    return mesh;
  }

  // ------------------------------------------------------------------------
  // ASSEMBLY 1: Planetary Reduction Gearset
  // ------------------------------------------------------------------------
  const planetaryGroup = new THREE.Group();
  masterAssembly.add(planetaryGroup);

  // Outer Ring Gear & Bezel
  const ringGearGroup = new THREE.Group();
  planetaryGroup.add(ringGearGroup);

  const outerBezel = reg(new THREE.Mesh(new THREE.TorusGeometry(2.1, 0.18, 20, 80), materials.stealthDark), materials.stealthDark);
  ringGearGroup.add(outerBezel);

  const redIndexRing = reg(new THREE.Mesh(new THREE.TorusGeometry(2.12, 0.04, 16, 80), materials.redMetal), materials.redMetal);
  ringGearGroup.add(redIndexRing);

  // Internal gear teeth along ring
  const ringTeethCount = 36;
  for (let i = 0; i < ringTeethCount; i++) {
    const angle = (i / ringTeethCount) * Math.PI * 2;
    const tooth = reg(new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.16, 0.25), materials.titanium), materials.titanium);
    tooth.position.set(Math.cos(angle) * 1.95, Math.sin(angle) * 1.95, 0);
    tooth.rotation.z = angle;
    ringGearGroup.add(tooth);
  }

  // Central Sun Gear
  const sunGearGroup = new THREE.Group();
  planetaryGroup.add(sunGearGroup);

  const sunHub = reg(new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.38, 48), materials.redMetal), materials.redMetal);
  sunHub.rotation.x = Math.PI / 2;
  sunGearGroup.add(sunHub);

  const sunShaft = reg(new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 1.8, 32), materials.titanium), materials.titanium);
  sunShaft.rotation.x = Math.PI / 2;
  sunGearGroup.add(sunShaft);

  for (let i = 0; i < 14; i++) {
    const angle = (i / 14) * Math.PI * 2;
    const tooth = reg(new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.16, 0.36), materials.goldBrass), materials.goldBrass);
    tooth.position.set(Math.cos(angle) * 0.62, Math.sin(angle) * 0.62, 0);
    tooth.rotation.z = angle;
    sunGearGroup.add(tooth);
  }

  // Planet Gears & Triangular Carrier
  const planetCarrierGroup = new THREE.Group();
  planetaryGroup.add(planetCarrierGroup);

  const carrierPlate = reg(new THREE.Mesh(new THREE.CylinderGeometry(1.3, 1.3, 0.08, 3), materials.stealthDark), materials.stealthDark);
  carrierPlate.rotation.x = Math.PI / 2;
  carrierPlate.position.z = 0.28;
  planetCarrierGroup.add(carrierPlate);

  const planets = [];
  const planetOrbitRadius = 1.28;
  for (let i = 0; i < 3; i++) {
    const pAngle = (i / 3) * Math.PI * 2;
    const pGroup = new THREE.Group();
    pGroup.position.set(Math.cos(pAngle) * planetOrbitRadius, Math.sin(pAngle) * planetOrbitRadius, 0);

    const pCore = reg(new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.32, 32), materials.goldBrass), materials.goldBrass);
    pCore.rotation.x = Math.PI / 2;
    pGroup.add(pCore);

    for (let j = 0; j < 10; j++) {
      const tAngle = (j / 10) * Math.PI * 2;
      const tMesh = reg(new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.14, 0.3), materials.titanium), materials.titanium);
      tMesh.position.set(Math.cos(tAngle) * 0.46, Math.sin(tAngle) * 0.46, 0);
      tMesh.rotation.z = tAngle;
      pGroup.add(tMesh);
    }

    const pin = reg(new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.5, 16), materials.redMetal), materials.redMetal);
    pin.rotation.x = Math.PI / 2;
    pGroup.add(pin);

    planetCarrierGroup.add(pGroup);
    planets.push({ group: pGroup, baseAngle: pAngle });
  }

  // ------------------------------------------------------------------------
  // ASSEMBLY 2: Swiss Horology Escapement (ETA 2895-2 Inspired)
  // ------------------------------------------------------------------------
  const horologyGroup = new THREE.Group();
  horologyGroup.visible = false;
  masterAssembly.add(horologyGroup);

  // Large Balance Wheel with Screws
  const balanceWheel = new THREE.Group();
  horologyGroup.add(balanceWheel);

  const balanceRim = reg(new THREE.Mesh(new THREE.TorusGeometry(1.8, 0.1, 16, 64), materials.goldBrass), materials.goldBrass);
  balanceWheel.add(balanceRim);

  // Cross arms (3 arms)
  for (let i = 0; i < 3; i++) {
    const armAngle = (i / 3) * Math.PI * 2;
    const arm = reg(new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.8, 0.06), materials.goldBrass), materials.goldBrass);
    arm.position.set(Math.cos(armAngle) * 0.9, Math.sin(armAngle) * 0.9, 0);
    arm.rotation.z = armAngle + Math.PI / 2;
    balanceWheel.add(arm);
  }

  // Perimeter inertia weight screws
  for (let i = 0; i < 16; i++) {
    const scAngle = (i / 16) * Math.PI * 2;
    const screw = reg(new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.18, 12), materials.titanium), materials.titanium);
    screw.position.set(Math.cos(scAngle) * 1.9, Math.sin(scAngle) * 1.9, 0);
    screw.rotation.z = scAngle;
    balanceWheel.add(screw);
  }

  // Coiled Hairspring (Archimedean Spiral Tube)
  const hairspringCurve = [];
  for (let t = 0; t <= Math.PI * 12; t += 0.2) {
    const r = 0.15 + t * 0.035;
    hairspringCurve.push(new THREE.Vector3(Math.cos(t) * r, Math.sin(t) * r, 0.08));
  }
  const hairspringGeo = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(hairspringCurve), 140, 0.02, 6, false);
  const hairspringMesh = reg(new THREE.Mesh(hairspringGeo, materials.redMetal), materials.redMetal);
  balanceWheel.add(hairspringMesh);

  // Pallet Fork & Ruby Jewels
  const palletForkGroup = new THREE.Group();
  palletForkGroup.position.set(-1.4, -1.2, 0);
  horologyGroup.add(palletForkGroup);

  const palletBody = reg(new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.14, 0.08), materials.titanium), materials.titanium);
  palletForkGroup.add(palletBody);

  // Synthetic Rubies
  const ruby1 = reg(new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.2, 0.1), materials.redMetal), materials.redMetal);
  ruby1.position.set(-0.35, 0.12, 0);
  palletForkGroup.add(ruby1);

  const ruby2 = reg(new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.2, 0.1), materials.redMetal), materials.redMetal);
  ruby2.position.set(0.35, 0.12, 0);
  palletForkGroup.add(ruby2);

  // Escape Wheel
  const escapeWheelGroup = new THREE.Group();
  escapeWheelGroup.position.set(-1.8, -2.1, 0);
  horologyGroup.add(escapeWheelGroup);

  const escRim = reg(new THREE.Mesh(new THREE.TorusGeometry(0.7, 0.06, 16, 32), materials.goldBrass), materials.goldBrass);
  escapeWheelGroup.add(escRim);

  for (let i = 0; i < 15; i++) {
    const ea = (i / 15) * Math.PI * 2;
    const tooth = reg(new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.18, 0.04), materials.goldBrass), materials.goldBrass);
    tooth.position.set(Math.cos(ea) * 0.74, Math.sin(ea) * 0.74, 0);
    tooth.rotation.z = ea + 0.3; // club tooth rake angle
    escapeWheelGroup.add(tooth);
  }

  // ------------------------------------------------------------------------
  // ASSEMBLY 3: 3-Axis Kinematic Gimbal Assembly
  // ------------------------------------------------------------------------
  const gimbalAssemblyGroup = new THREE.Group();
  gimbalAssemblyGroup.visible = false;
  masterAssembly.add(gimbalAssemblyGroup);

  // Outer Yaw Ring
  const outerYawRing = reg(new THREE.Mesh(new THREE.TorusGeometry(2.6, 0.09, 16, 72), materials.redMetal), materials.redMetal);
  gimbalAssemblyGroup.add(outerYawRing);

  // Pitch Ring
  const pitchRingGroup = new THREE.Group();
  gimbalAssemblyGroup.add(pitchRingGroup);

  const pitchRing = reg(new THREE.Mesh(new THREE.TorusGeometry(2.0, 0.08, 16, 64), materials.titanium), materials.titanium);
  pitchRingGroup.add(pitchRing);

  // Roll Cradle & Camera Payload
  const rollCradleGroup = new THREE.Group();
  pitchRingGroup.add(rollCradleGroup);

  const rollRing = reg(new THREE.Mesh(new THREE.TorusGeometry(1.4, 0.07, 16, 48), materials.stealthDark), materials.stealthDark);
  rollCradleGroup.add(rollRing);

  const cameraPayload = reg(new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.6, 0.8), materials.stealthDark), materials.stealthDark);
  rollCradleGroup.add(cameraPayload);

  const lensBarrel = reg(new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.35, 0.5, 32), materials.goldBrass), materials.goldBrass);
  lensBarrel.rotation.x = Math.PI / 2;
  lensBarrel.position.z = 0.5;
  rollCradleGroup.add(lensBarrel);

  // Brushless Motor Bells on pivots
  const motor1 = reg(new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.28, 24), materials.goldBrass), materials.goldBrass);
  motor1.position.set(2.6, 0, 0);
  motor1.rotation.z = Math.PI / 2;
  gimbalAssemblyGroup.add(motor1);

  const motor2 = reg(new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.28, 24), materials.goldBrass), materials.goldBrass);
  motor2.position.set(0, 2.0, 0);
  pitchRingGroup.add(motor2);

  // ------------------------------------------------------------------------
  // 3D Floating Dimension Callouts (Leader Lines & Markers)
  // ------------------------------------------------------------------------
  const dimensionsGroup = new THREE.Group();
  dimensionsGroup.visible = false;
  masterAssembly.add(dimensionsGroup);

  // Caliper Line 1 (Outer Diameter)
  const lineGeo = new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(-2.1, 2.3, 0),
    new THREE.Vector3(2.1, 2.3, 0)
  ]);
  const dimLine = new THREE.Line(lineGeo, new THREE.LineBasicMaterial({ color: 0x38bdf8 }));
  dimensionsGroup.add(dimLine);

  // Ticks at ends
  const tick1 = new THREE.Line(new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(-2.1, 2.15, 0),
    new THREE.Vector3(-2.1, 2.45, 0)
  ]), new THREE.LineBasicMaterial({ color: 0x38bdf8 }));
  const tick2 = new THREE.Line(new THREE.BufferGeometry().setFromPoints([
    new THREE.Vector3(2.1, 2.15, 0),
    new THREE.Vector3(2.1, 2.45, 0)
  ]), new THREE.LineBasicMaterial({ color: 0x38bdf8 }));
  dimensionsGroup.add(tick1);
  dimensionsGroup.add(tick2);

  // ------------------------------------------------------------------------
  // Lighting Environment
  // ------------------------------------------------------------------------
  scene.add(new THREE.HemisphereLight(0xffffff, 0x050810, 1.4));
  const keyLight = new THREE.DirectionalLight(0xffffff, 2.6);
  keyLight.position.set(4, 5, 6);
  scene.add(keyLight);

  const redAccentLight = new THREE.PointLight(0xff2d55, 14, 12);
  redAccentLight.position.set(-4, -2, 3);
  scene.add(redAccentLight);

  const fillCyanLight = new THREE.PointLight(0x38bdf8, 8, 10);
  fillCyanLight.position.set(3, -4, 2);
  scene.add(fillCyanLight);

  // ------------------------------------------------------------------------
  // Orbit, Drag & Pan Controls
  // ------------------------------------------------------------------------
  let targetRotX = 0.2;
  let targetRotY = -0.4;
  let currentRotX = 0.2;
  let currentRotY = -0.4;
  let targetZoom = 7.5;
  let panX = 0, panY = 0;
  let dragging = false;
  let panning = false;
  let lastX = 0, lastY = 0;

  const handleResize = () => {
    const box = canvas.parentElement.getBoundingClientRect();
    renderer.setSize(box.width, box.height, false);
    camera.aspect = box.width / box.height;
    camera.updateProjectionMatrix();
  };
  handleResize();
  window.addEventListener('resize', handleResize);

  canvas.addEventListener('pointerdown', (e) => {
    dragging = true;
    panning = e.shiftKey;
    lastX = e.clientX;
    lastY = e.clientY;
    canvas.setPointerCapture(e.pointerId);
  });

  canvas.addEventListener('pointermove', (e) => {
    if (dragging) {
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      if (panning) {
        panX += dx * 0.006;
        panY -= dy * 0.006;
        masterAssembly.position.set(panX, panY, 0);
      } else {
        targetRotY += dx * 0.009;
        targetRotX += dy * 0.009;
      }
      lastX = e.clientX;
      lastY = e.clientY;
    } else {
      const rect = canvas.getBoundingClientRect();
      const normX = (e.clientX - rect.left) / rect.width - 0.5;
      const normY = (e.clientY - rect.top) / rect.height - 0.5;
      targetRotY = normX * 0.7;
      targetRotX = normY * 0.5;
    }
  });

  canvas.addEventListener('pointerup', () => { dragging = false; panning = false; });
  canvas.addEventListener('pointerleave', () => { dragging = false; panning = false; });

  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    targetZoom = THREE.MathUtils.clamp(targetZoom + e.deltaY * 0.005, 5.0, 11.0);
  }, { passive: false });

  // ------------------------------------------------------------------------
  // HUD UI Controls Hookups
  // ------------------------------------------------------------------------
  // Mode Switcher
  const modePills = document.querySelectorAll('.mode-pill');
  const hudToleranceBadge = document.querySelector('#hudToleranceBadge');
  const explodeSliderGroup = document.querySelector('#explodeSliderGroup');

  modePills.forEach(pill => {
    pill.addEventListener('click', () => {
      AudioFX.playClick();
      modePills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      activeAssemblyMode = pill.dataset.mode;

      planetaryGroup.visible = activeAssemblyMode === 'planetary';
      horologyGroup.visible = activeAssemblyMode === 'horology';
      gimbalAssemblyGroup.visible = activeAssemblyMode === 'gimbal';

      if (explodeSliderGroup) {
        explodeSliderGroup.style.display = activeAssemblyMode === 'planetary' ? 'flex' : 'none';
      }

      if (hudToleranceBadge) {
        if (activeAssemblyMode === 'planetary') hudToleranceBadge.textContent = 'TOLERANCE: ±0.015 mm';
        if (activeAssemblyMode === 'horology') hudToleranceBadge.textContent = 'CALIBRE: ETA 2895-2';
        if (activeAssemblyMode === 'gimbal') hudToleranceBadge.textContent = 'GIMBAL: 3-AXIS BRUSHLESS';
      }
    });
  });

  // Wireframe Toggle
  const wireframeBtn = document.querySelector('#wireframeToggle');
  if (wireframeBtn) {
    wireframeBtn.addEventListener('click', () => {
      AudioFX.playClick();
      isWireframeMode = !isWireframeMode;
      wireframeBtn.classList.toggle('active', isWireframeMode);
      registeredMeshes.forEach(({ mesh, solidMat }) => {
        mesh.material = isWireframeMode ? materials.wireframeRed : solidMat;
      });
    });
  }

  // Section Cut Toggle (Clipping Plane)
  const sectionCutBtn = document.querySelector('#sectionCutToggle');
  if (sectionCutBtn) {
    sectionCutBtn.addEventListener('click', () => {
      AudioFX.playClick();
      isSectionCutMode = !isSectionCutMode;
      sectionCutBtn.classList.toggle('active', isSectionCutMode);
      registeredMeshes.forEach(({ mesh }) => {
        mesh.material.clippingPlanes = isSectionCutMode ? [clipPlane] : [];
        mesh.material.clipShadows = true;
        mesh.material.needsUpdate = true;
      });
    });
  }

  // Dimensions Callouts Toggle
  const dimensionBtn = document.querySelector('#dimensionToggle');
  if (dimensionBtn) {
    dimensionBtn.addEventListener('click', () => {
      AudioFX.playClick();
      isDimensionsVisible = !isDimensionsVisible;
      dimensionBtn.classList.toggle('active', isDimensionsVisible);
      dimensionsGroup.visible = isDimensionsVisible;
    });
  }

  // Explode View Slider
  const explodeSlider = document.querySelector('#explodeSlider');
  const explodeValText = document.querySelector('#explodeValText');
  if (explodeSlider) {
    explodeSlider.addEventListener('input', (e) => {
      AudioFX.playRatchet();
      explodedValue = parseFloat(e.target.value) / 100;
      if (explodeValText) {
        explodeValText.textContent = `${Math.round(explodedValue * 100)}%`;
      }
    });
  }

  // Speed Toggle
  const speedToggle = document.querySelector('#speedToggle');
  if (speedToggle) {
    speedToggle.addEventListener('click', () => {
      AudioFX.playClick();
      rotationSpeed = rotationSpeed === 1.0 ? 2.5 : (rotationSpeed === 2.5 ? 0.4 : 1.0);
      speedToggle.textContent = `${rotationSpeed}x SPEED`;
    });
  }

  const telemetryRpm = document.querySelector('#telemetryRpm');

  // ------------------------------------------------------------------------
  // Animation Loop
  // ------------------------------------------------------------------------
  let clock = new THREE.Clock();
  let lastEscapementTick = 0;

  const renderLoop = () => {
    requestAnimationFrame(renderLoop);
    const delta = clock.getDelta();
    const elapsedTime = clock.getElapsedTime();

    // Inertial motion
    currentRotX += (targetRotX - currentRotX) * 0.07;
    currentRotY += (targetRotY - currentRotY) * 0.07;
    camera.position.z += (targetZoom - camera.position.z) * 0.08;

    masterAssembly.rotation.x = currentRotX;
    masterAssembly.rotation.y = currentRotY;

    // Kinematics for Active Mode
    if (activeAssemblyMode === 'planetary') {
      const sunSpeed = elapsedTime * 1.8 * rotationSpeed;
      sunGearGroup.rotation.z = sunSpeed;

      const carrierSpeed = sunSpeed * 0.28;
      planetCarrierGroup.rotation.z = carrierSpeed;
      planets.forEach(p => { p.group.rotation.z = -sunSpeed * 0.8; });

      // Exploded offsets
      sunGearGroup.position.z = explodedValue * 1.8;
      planetCarrierGroup.position.z = explodedValue * 1.0;
      ringGearGroup.position.z = -explodedValue * 1.2;

      planets.forEach(p => {
        const r = planetOrbitRadius + explodedValue * 0.6;
        p.group.position.x = Math.cos(p.baseAngle) * r;
        p.group.position.y = Math.sin(p.baseAngle) * r;
      });

      if (telemetryRpm) {
        const rpm = Math.round(120 * rotationSpeed + Math.sin(elapsedTime * 3) * 6);
        telemetryRpm.textContent = `${rpm} RPM · RATIO 1:3.4`;
      }
    } else if (activeAssemblyMode === 'horology') {
      // 4 Hz horology balance oscillation (28,800 vph standard Swiss movement)
      const oscFrequency = 4 * Math.PI * 2 * rotationSpeed;
      const balanceAngle = Math.sin(elapsedTime * oscFrequency) * 1.2;
      balanceWheel.rotation.z = balanceAngle;

      // Pallet fork flicks at reversal points
      const forkAngle = Math.sign(Math.cos(elapsedTime * oscFrequency)) * 0.25;
      palletForkGroup.rotation.z = forkAngle;

      // Escape wheel stepping
      escapeWheelGroup.rotation.z = -elapsedTime * 1.2 * rotationSpeed;

      // Trigger subtle tick sound at balance turning points
      if (Math.abs(Math.sin(elapsedTime * oscFrequency)) > 0.98 && (elapsedTime - lastEscapementTick > 0.15)) {
        AudioFX.playEscapementTick();
        lastEscapementTick = elapsedTime;
      }

      if (telemetryRpm) {
        telemetryRpm.textContent = `28,800 VPH · 4.0 Hz ESCAPEMENT`;
      }
    } else if (activeAssemblyMode === 'gimbal') {
      // 3-Axis Gimbal Kinematic Sweeps
      gimbalAssemblyGroup.rotation.z = Math.sin(elapsedTime * 0.7 * rotationSpeed) * 0.4;
      pitchRingGroup.rotation.y = Math.cos(elapsedTime * 0.9 * rotationSpeed) * 0.5;
      rollCradleGroup.rotation.x = Math.sin(elapsedTime * 1.1 * rotationSpeed) * 0.3;

      if (telemetryRpm) {
        telemetryRpm.textContent = `IMU 6-DOF · STABILIZED`;
      }
    }

    camera.lookAt(0, 0, 0);
    renderer.render(scene, camera);
  };

  renderLoop();
}

// ==========================================================================
// 8. Scroll Reveal & Auto-Sync
// ==========================================================================
function initScrollReveal() {
  const reveals = document.querySelectorAll('.reveal');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
      }
    });
  }, { threshold: 0.1 });

  reveals.forEach(el => observer.observe(el));
}

// Listen for live updates from Admin Panel (same window or other tabs)
window.addEventListener('storage', (e) => {
  if (e.key === PortfolioStore.STORAGE_KEY) {
    portfolioDb = PortfolioStore.get();
    renderProfileContent();
    renderProjects();
  }
});

window.addEventListener('portfolioDataUpdated', (e) => {
  portfolioDb = e.detail || PortfolioStore.get();
  renderProfileContent();
  renderProjects();
});

// Initial Boot
document.addEventListener('DOMContentLoaded', () => {
  renderProfileContent();
  renderProjects();
  initSoundToggle();
  initHeroThreeMechanism();
  initScrollReveal();
});
